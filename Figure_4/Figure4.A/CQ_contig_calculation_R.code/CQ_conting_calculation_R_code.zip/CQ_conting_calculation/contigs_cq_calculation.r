if (!require(dplyr)) install.packages('dplyr') #  is a grammar of data manipulation
library(dplyr)

#Set wd based on source----------------------------------------------------------
setwd(dirname(rstudioapi::getActiveDocumentContext()$path))
getwd()
dir.create("output_data/")

# Data_wrangling ----------------------------------------------------------
#Import the EGII ccap3.2 Genes and CQ values calculated
my_data <- read.table("input_data/contigs_cq_calculation.txt", header=T, sep="")
#Import the contigs coordinates from .agp file
named_assembly_sc1.sc6<- read.table("input_data/named_assembly_sc1-sc6.agp",  header=T, sep="\t")

#Sumarize the data considering the contig, the gene and the CQ
#Group the data based in the contig ID and calculate the median

df <- my_data %>%
  group_by(c.label) %>%
  summarize(cq_contig = median(cq_EGII, na.rm = TRUE))

#Join the data cq_median calculated for each contig with the gene information
my_cq_contigs<-inner_join(my_data, df, by="c.label")

#Join the contigs coordinates to the cq values
my_cq_contigs_coord<-inner_join(my_cq_contigs, named_assembly_sc1.sc6, by ="c.label")

#Select columns
my_cq_contigs_coord<-select(my_cq_contigs_coord,c.label, c_start, c_end, cq_contig)

# Remove duplicated rows based on the contig ID
my_cq_contigs_coord<-my_cq_contigs_coord %>% distinct(c.label, .keep_all = TRUE)

#Count the number of genes that are mapping in each contig
df1 <- my_data %>%
group_by(c.label) %>%
summarise(counts = n())

#Filter contigs with more than 10 genes
df2<-subset(df1, df1$counts>=10)

#Creat a final table with the contigs in both sets
my_cq_contigs_coord_10<-inner_join(my_cq_contigs_coord, df2, by="c.label")

write.table(my_cq_contigs_coord_10, file="output_data/my_cq_contigs_coord_10.txt")



